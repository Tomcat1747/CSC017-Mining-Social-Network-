import java.util.*;

public class Center {
	// Create a List of Centers
        List<center> centerList;
        // Create HashMap
        HashMap<Integer, Integer> map;
        // Make a Comparator to Sort the List of Center
        class sortByCount implements Comparator<center>
        {
            // Sort by the Count of Each Center
            public int compare(center a, center b)
            {
                // Get the Count of Center A
                int countA = a.getCount();
                // Get the Count of Center B
                int countB = b.getCount();
                // Return the Comparison
                return countB - countA;
            }
        }
	// the nested class used to define a center
	public static class center {
		int id; // the center
		int count; // the betweenness centrality

		center(int i, int c) {
			id = i;
			count = c;
		}

		int getId() {
			return id;
		}

		int getCount() {
			return count;
		}
	}

	public Center(Graph g) {
            // Initialize the an Array List to Hold the Centers
            centerList = new ArrayList<>();
            map = new HashMap<>();
            for(Integer vertex: g.getVertices())
            {
                map.put(vertex, 0);
            }
            // Go Through the All the Vertices from the Graph and Label Them as
            // the Source
            for(Integer source: g.getVertices())
            {
                // Run BFS for the Source
                BFS(g, source);
            }
            for(Integer vertexa: g.getVertices())
            {
                centerList.add(new center(vertexa, map.get(vertexa)));
            }
            // Sort the List of Centers
            Collections.sort(centerList, new sortByCount());
	}

	public List<center> top(int k) {
		// Create a List to Hold the Top K Centers
                List<center> topK = new ArrayList<>();
                // Go Through the First K Elements of List of Centers
                for(int i = 0; i < k; i++)
                {
                    // Add the Center into the Array List
                    topK.add(centerList.get(i));
                }
                // Return the Top K List
                return topK;
	}
        
        private void BFS(Graph g, int source)
        {
            // Create a List to Act as a Queue for Used Vertices
            LinkedList<Integer> queue = new LinkedList<>();
            // Create a HashMap to Store Which Each Vertex Connects to
            HashMap<Integer, Integer> edgeTo = new HashMap<>();
            // Create a HashMap to Store the Distance from Source of the Vertex
            HashMap<Integer, Integer> distToSource = new HashMap<>();
            // Create a HashSet to Store the Visited Vertices
            HashSet<Integer> visited = new HashSet<>();
            // Add the Source to the End of the Queue
            queue.addLast(source);
            // Add the Source to the Visited HashSet
            visited.add(source);
            // Set the Distance to Source to be '0'
            distToSource.put(source, 0);
            // Generate a While Loop that Will Repeat as Long as the Queue is Not
            // Empty
            while(!queue.isEmpty())
            {
                // Take the Current Vertex from the Queue
                int vertex = queue.remove();
                // Mark the Vertex as Visited
                visited.add(vertex);
                // Create an Iterator for the Next Values Which Follow Vertex
                Iterator<Integer> iterator = g.adj(vertex).iterator();
                // Generate a While Loop Which Will Run as Long as the Iterator 
                // Has a Next Value
                while(iterator.hasNext())
                {
                    // Set the Current Position of the Iterator to be the Neighbor
                    int neighbor = iterator.next();
                    // Check that the Neighbor Has Not Been Visited
                    if(!visited.contains(neighbor))
                    {
                        // Mark the Neighbor as Visited
                        visited.add(neighbor);
                        // Add the Neighbor to the End of Queue
                        queue.addLast(neighbor);
                        // Set the Distance to the Source for the Neighbor
                        distToSource.put(neighbor, distToSource.get(vertex) + 1);
                        // Connect the Neigbor to the Vertex
                        edgeTo.put(neighbor, vertex);
                    }
                }
            }
            for(Integer i: visited)
            {
                if(i != source)
                {
                    for(int x = i; x != source; x = edgeTo.get(x))
                    {
                        map.put(x, map.get(x) + 1);
                    }
                    map.put(source, map.get(source) + 1);
                }
            }
        }
}
