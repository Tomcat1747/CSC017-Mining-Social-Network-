import java.util.*;

public class Diameter {
	// Set a List to Hold the Top Diameters
        List<Integer> diameterList;
        // Create a Compartor for the List of Diameters
        class sortByDiameter implements Comparator<Integer>
        {
            // Sort the Diameters from Largest to Smallest
            public int compare(Integer a, Integer b)
            {
                // Return the Comparision
                return b.compareTo(a);
            }
        }
	public Diameter(Graph g) {
            // Initalize the Array List
            diameterList = new ArrayList<>();
            // Get the Set of Vertices from the Graph
            Set<Integer> setOfVertices = g.getVertices();
            // Go through Each Vertice in the Graph
            for(Integer source: setOfVertices)
            {
                // Add the Diameter into the List
                diameterList.add(findDiameter(g, source));
            }
            // Sort the List of Diameters
            Collections.sort(diameterList, new sortByDiameter());
	}

	public int getDiameter() {
            // Return the First Element from the List
            return diameterList.get(0);
	}
        
        // Return the Largest Diameter
        private int findDiameter(Graph g, int source)
        {
            // Create a Linked List to Hold the Used Sources
            LinkedList<Integer> queue = new LinkedList<>();
            // Create a HashMap to Hold the Distance to Source
            HashMap<Integer, Integer> distanceToSource = new HashMap<>();
            // Add the Source to the End of the List
            queue.addLast(source);
            // Add the Distance to Source to From the Source in the HashMap as '0'
            distanceToSource.put(source, 0);
            // Generate a While Loop Which Will Repeat as Long as the Queue is Not
            // Empty
            while(!queue.isEmpty())
            {
                // Set a Variable to Take the First Element from the Queue
                int vertex = queue.remove();
                // Go Through the Neighbors of the Given Vertex
                for(Integer i: g.adj(vertex))
                {
                    // Check to Make Sure That the Neighbor is Not is the HashMap
                    if(!distanceToSource.containsKey(i))
                    {
                        // Add the Neighbor to the End of the Queue
                        queue.addLast(i);
                        // Set the Distance to Source
                        distanceToSource.put(i, 1 + distanceToSource.get(vertex));
                    }
                }
            }
            // Set the Largest Diameter to be '-1'
            int largestDiameter = -1;
            // Go Through the Set of Vertices from the Graph
            for(Integer j: g.getVertices())
            {
                // Check if the Distance at the Current Vertex is Larger than the 
                // Current Diameter
                if(distanceToSource.get(j) > largestDiameter)
                {
                    // Set the Largest Diameter to be the Distance from the Source 
                    // to the Vertex
                    largestDiameter = distanceToSource.get(j);
                }
            }
            // Return the Largest Diameter
            return largestDiameter;
        }
}
