import java.util.*;

public class Ego {
	// Create a List of Ego Networks
        List<egonet> egoList;
        // Create a Comparator for the List of Ego Networks
        class sortByEgo implements Comparator<egonet>
        {
            // Compare Two Ego Networks
            public int compare(egonet a, egonet b)
            {
                // Get the Number of Edges from 'a'
                int edgesA = a.getG().getE();
                // Get the Number of Edges from 'b'
                int edgesB = b.getG().getE();
                // Return the Comparison of the Two
                return edgesB - edgesA;
            }
        }
	// the nested class used to define a egonet
	public static class egonet {
		int center; // center of the egonet
		Graph G; // subgraph that represents the egonet

		egonet(int c, Graph g) {
			center = c;
			G = g;
		}

		int getCenter() {
			return center;
		}

		Graph getG() {
			return G;
		}
	}

	public Ego(Graph g) {
            egoList = new ArrayList<>();
            // Get an Array of the Vertices in the Given Graph
            int[] arrayOfVertices = toIntArray(g.getVertices());
            // Traverse Through the Array of Vertices
            for(int i = 0; i < arrayOfVertices.length; i++)
            {
                // Record the Current Vertex as the Center of Ego Network
                int placeHolderCenter = arrayOfVertices[i];
                // Create an Array of the Neighbors of the Center Vertex
                int[] arrayOfNeighbors = toIntArray(g.adj(placeHolderCenter));
                // Create a New Graph
                Graph placeHolderGraph = new Graph();
                // Add 'placeHolderCenter' to the Graph
                placeHolderGraph.addVertex(placeHolderCenter);
                // Traverse Through the Array of Neighbors
                for(int j = 0; j < arrayOfNeighbors.length; j++)
                {
                    // Add the Vertex into the Graph
                    placeHolderGraph.addVertex(arrayOfNeighbors[j]);
                    // Make a Connection Between the Center Vertex and the New Vertex
                    placeHolderGraph.addEdge(placeHolderCenter, arrayOfNeighbors[j]);
                    // Make a Connection Between the New Vertex and the Center Vertex
                    placeHolderGraph.addEdge(arrayOfNeighbors[j], placeHolderCenter);
                }
                // Go Through the Set of Neighbors to the Center
                for(Integer y: g.adj(placeHolderCenter))
                {
                    // Go Through the neighbors of the Given Vertex
                    for(Integer z: g.adj(y))
                    {
                        if(g.adj(y).contains(z))
                        {
                            placeHolderGraph.addEdge(z, y);
                        }
                    }
                }
                // Create an Ego Network
                egonet data = new egonet(placeHolderCenter, placeHolderGraph);
                // Add the Ego Network into the List
                egoList.add(data);
            }
            // Sort 'egoList'
            Collections.sort(egoList, new sortByEgo());
	}

	public List<egonet> top(int k) {
            // Create a List for Ego Networks
            List<egonet> topK = new ArrayList<>();
            // Go Through the First k Elements within the Graph
            for(int i = 0; i < k; i++)
            {
                // Top Ego Networks
                topK.add(egoList.get(i));
            }
            // Return the Top k List
            return topK;
	}
        
        // Converts a Set<Integer> into an Array of Integers
        private int[] toIntArray(Set<Integer> set)
        {
            // Create an Empty Array with the Same Size of the Set
            int[] array = new int[set.size()];
            // Set the Integer 'i' to be 0
            int i = 0;
            // Go Through the Values in the Set
            for(Integer val : set)
            {
                // Add the Value into the Array
                array[i++] = val;
            }
            // Return the Array
            return array;
        }
}