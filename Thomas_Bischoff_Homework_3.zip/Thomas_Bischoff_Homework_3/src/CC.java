import java.util.*;

public class CC {
	// Create a List to Hold the Connected Components
        List<cc> ccList;
        // Create a Boolean Array that Will Mark if a Vertex has Been Visited
        private boolean[] visited;
        // Create an Integer Array to Hold the Value of Vertices from the Graph
        private int[] vertices;
        // Create an Integer Array that Will Store the Sizes of Their Respective 
        // Vertex
        private int[] sizeOfVertex;
        // Create a Value to Hold the Total Number of Connected Components
        private int count;
        // Set ID Number
        private int idNumber = 1;
        // Create a Comparator to Sort the List of Connected Components
        class sortCC implements Comparator<cc>
        {
            // Sort the List of Connected Componets by Size
            public int compare(cc a, cc b)
            {
                // Get the Size of the First Connected Component
                int sizeA = a.size;
                // Get the Size of the Second Connected Component
                int sizeB = b.size;
                // Return the Comparison
                return sizeB - sizeA;
            }
        }
	// the nested class used to define a connected component
	public static class cc {
		int id; // the id of the component
		int size; // the size of the component

		cc(int i, int s) {
			id = i;
			size = s;
		}

		int getId() {
			return id;
		}

		int getSize() {
			return size;
		}
	}

	public CC(Graph g) {
		// Initialize an ArrayList to Hold the Connected Components
                ccList = new ArrayList<>();
                // Initialize the Size of Visited Array to Be the Number of Vertices
                visited = new boolean[Collections.max(g.getVertices()) + 1];
                // Initialize the Size of Vertices Array to Be the Number of Vertices
                vertices = new int[Collections.max(g.getVertices()) + 1];
                // Initialize the Size of Size of Vertex to Be the Number of Vertices
                sizeOfVertex = new int[Collections.max(g.getVertices()) + 1];
                // Iterate Through the Vertices from the Graph Lable them as Source
                for(Integer source: g.getVertices())
                {
                    // Check that the Source Has Not Already Been Visited
                    if(!visited[source])
                    {
                        // Run DFS
                        DFS(g, source);
                        // Increment the Count
                        count++;
                    }
                }
                // Create a For Loop that Will Go Through the Vertices of the Graph
                for(Integer vertex: g.getVertices())
                {
                    // Create a New Connected Components Type of Data
                    cc data = new cc(vertex + 1, sizeOfVertex[vertex]);
                    // Add the data into the ArrayList
                    ccList.add(data);
                }
            // Sort the List
            Collections.sort(ccList, new sortCC());
	}

	public int count() {
		// Return Count
		return count;
	}

	public List<cc> top(int k) {
		// Create a Array List to Hold the Top K Values
		List<cc> topK = new ArrayList<>();
                // Go Through the First K Element of the CC List
                for(int i = 0; i < k; i++)
                {
                    // Add the Value into the List of Top K
                    topK.add(ccList.get(i));
                }
                // Return the Top K Values
                return topK;
	}
        
        // Run DFS from the Given Source
        private void DFS(Graph g, int source)
        {
            // Mark that the Source has been Visited
            visited[source] = true;
            // Set the Vertex of the Source to be Equal to the Count
            vertices[source] = count;
            // Increment the Size of Vertex at Count
            sizeOfVertex[count]++;
            // Iterate Through the Neighbors of the Given Source
            for(Integer neighbor: g.adj(source))
            {
                // Check to See if the Neighbor Has Not Been Visited
                if(!visited[neighbor])
                {
                    // Re-Run DFS
                    DFS(g, neighbor);
                }
            }
        }
}
