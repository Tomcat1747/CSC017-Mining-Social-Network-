import java.util.*;

public class Influence {
	// Create a List of Influencers
        List<influencer> influencerList;
        // Comparator for Influencer List
        class sortByInfluence implements Comparator<influencer>
        {
            // Sort by Power of the Influencer
            public int compare(influencer a, influencer b)
            {
                // Get the Power of the First Influencer
                double powerA = a.getPower();
                // Get the Power of the Second Influencer
                double powerB = b.getPower();
                // Return the Comparison
                return (int) (powerB - powerA);
            }
        }
	// the nested class used to define a influencer
	public static class influencer {
		int source; // the influencer
		double power; // the impact of this influencer

		influencer(int i, double p) {
			source = i;
			power = p;
		}

		int getSource() {
			return source;
		}

		double getPower() {
			return power;
		}
	}

	public Influence(Graph g) {
            // Set Up a Array List to Hold the Revelvant Data
            influencerList = new ArrayList<>();
            // Get a Set of All the Vertices in the Graph
            Set<Integer> setOfVertices = g.getVertices();
            // Go Through the Vertices of the Graph
            for(Integer i: setOfVertices)
            {
                // Set the Current Vertex to be the Source
                int placeHolderSource = i;
                // Get the Power of the Source
                double power = powerCalculator(g, placeHolderSource);
                // Create a New Influencer
                influencer data = new influencer(placeHolderSource, power);
                // Add the Power into the List
                influencerList.add(data);
            }
            // Sort the Array List by Power
             Collections.sort(influencerList, new sortByInfluence());
	}

	public List<influencer> top(int k) {
            List<influencer> topK = new ArrayList<>();
            for(int i = 0; i < k; i++)
            {
                topK.add(influencerList.get(i));
            }
            return topK;
	}

        // Calculate the Power of the Source
        private double powerCalculator(Graph g, int source)
        {
            // Create a Variable to Hold the Power of the Source
            double power = 0;
            // Create a HashSet to Mark a Vertex as Visited
            HashSet<Integer> visited = new HashSet<Integer>();
            // Create an Array to to Store the Distances Between the Vertex and the 
            // Source
            HashMap<Integer, Integer> distTo = new HashMap<Integer, Integer>();
            // Create an Array Which Stores the Edges of the Vertices
            HashMap<Integer, Integer> edgeTo = new HashMap<Integer, Integer>();
            // Create a Queue to Hold the Currentlly in Use Vertices
            LinkedList<Integer> queue = new LinkedList<>();
            // Add the Source into the Queue
            queue.addLast(source);
            // Set the Distance to the Source from the Source to be '0'
            distTo.put(source, 0);
            // Loop for as Long as the Queue is Not Empty
            while(!queue.isEmpty())
            {
                // Take Out the First Element from the Queue
                int vertex = queue.remove();
                // Mark the Vertex as Visited
                visited.add(vertex);
                // Check to Make Sure that the Vertex is Not the Same as the Source
                if(vertex != source)
                {
                    // Update the Power of the Source
                    power += 1 / Math.pow(2, (distTo.get(vertex) - 1));
                }
                // Create an Iterator for the Neighbors of the Vertex
                Iterator<Integer> iterator = g.adj(vertex).iterator();
                // Iterate Throuhg the List
                while(iterator.hasNext())
                {
                    // Get the Neighbor of the Vertex
                    int neighbor = iterator.next();
                    // Make Sure that the Neighbor has Not Been Visited
                    if(!visited.contains(neighbor))
                    {
                        // Mark the Neighbor as Visited
                        visited.add(neighbor);
                        // Add the Neighbor into the Queue
                        queue.addLast(neighbor);
                        // Update the Distance for the Neighbor
                        distTo.put(neighbor, distTo.get(vertex) + 1);
                    }
                }
            }
            // Return the Power
            return power;
        }
}
